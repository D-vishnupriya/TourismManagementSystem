package com.example.spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.spring.entity.Admin;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Long>
{

	Admin findByAdminRoomType(String adminRoomType);

	Admin findByAdminPackage(Float adminPackage);

	Admin findByAdminAccomodationType(String adminAccomodationType);

	Admin findByAdminEmailId(String adminEmailId);

	Admin findByAdminPassword(String adminPassword);

	Admin findByAdminName(String adminName);

}
