package com.example.spring.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.spring.entity.Visitor;
@Repository
public interface VisitorRepository  extends JpaRepository<Visitor, Long>
{

	Visitor findByVisitorDestination(String visitorDestination);

	Visitor findByVisitorAddress(String visitorAddress);

	Visitor findByVisitorEmailId(String visitorEmailId);

	Visitor findByVisitorMobileNumber(String visitorMobileNumber);

	Visitor findByVisitorName(String visitorName);

	Visitor save(Visitor visDB);

	//Optional<Visitor> findById(Long visitorId);

	//void deleteById(Long visitorId);

	List<Visitor> findAll();

}
